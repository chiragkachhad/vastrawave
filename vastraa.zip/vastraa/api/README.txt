PRODUCT MANAGER — SERVER MODE SETUP  (2 minute ka kaam)
=======================================================

Ye folder hosting par upload kar do. Agar aapki hosting par PHP chalti hai
(Hostinger / Bluehost / GoDaddy / cPanel — lagbhag sab me chalti hai),
to Product Manager "LIVE SERVER MODE" me chalega:

   Panel me change -> "🚀 Publish" -> WEBSITE PAR TURANT LIVE
   Koi file upload nahi. Koi FTP nahi. Mobile se bhi chalega.

STEPS
-----
1. api/config.php kholo aur TOKEN badal do:
       "token" => "vastraa2026"   ->   "token" => "koi-bhi-lamba-random-123"

2. Poori site hosting par upload karo (jaise abhi karti hai).

3. Permissions check karo (cPanel > File Manager > right-click > Permissions):
       data/                 755  (ya 775)
       assets/js/            755  (ya 775)   <- products-live-data.js yahan banta hai
       assets/img/uploads/   775             <- photo upload yahan hoti hai

4. Panel kholo:  yourstore.com/tools/product-manager.html
   Upar "● LIVE SERVER MODE" likha aayega — matlab sab set hai.

5. Password badalna ho to tools/product-manager.html me:
       const PASS = "apna-password";   // <-- yahan apna password

AGAR PHP NAHI HAI (pure static hosting)
---------------------------------------
Panel phir bhi chalega "LOCAL MODE" me:
   Change karo -> "🚀 Publish" -> products-live-data.js download hogi
   -> use assets/js/ me upload kar do (replace YES). Bas 30 second.

SECURITY
--------
- Token sirf aap aur panel ke beech me hai. Ise kisi ke saath share mat karo.
- Chaahe to api/ folder ko .htaccess se password-protect kar sakte ho
  (par tab panel browser se save nahi kar payega — tab local mode use karo).
- data/products.json = backup. Kabhi-kabhi download kar ke rakh lo.

TEST
----
Browser me kholo:  yourstore.com/api/products.php?action=ping
{"ok":true,...} aaye to sab theek hai.
