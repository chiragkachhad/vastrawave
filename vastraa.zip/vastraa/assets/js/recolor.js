/* ============================================================
   RECOLOR — kapde ka asal rang badlo (photo pixel-level recolor)
   clothesline.html ke QuickView wala wahi tested algorithm,
   ab shared file me taaki product page (PDP) bhi use kar sake.
   Sirf tint nahi: har pixel ka hue/lightness target colour ki
   taraf shift hota hai, shading/folds barkarar rehte hain.
   Transparent cutout (WebP) par sabse saaf chalta hai — background
   ke transparent pixel chhode jate hain.
   ============================================================ */
(function () {
  function clamp01(v){ return v < 0 ? 0 : (v > 1 ? 1 : v); }
  function rgbToHsl(r, g, b){
    r /= 255; g /= 255; b /= 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
    if (d){
      if (mx === r) h = ((g - b) / d) % 6;
      else if (mx === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60; if (h < 0) h += 360;
    }
    var l = (mx + mn) / 2;
    var s = d ? d / (1 - Math.abs(2 * l - 1)) : 0;
    return [h, clamp01(s), l];
  }
  function hslToRgb(h, s, l){
    h = ((h % 360) + 360) % 360;
    var c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = l - c / 2;
    var r = 0, g = 0, b = 0;
    if (h < 60){ r = c; g = x; } else if (h < 120){ r = x; g = c; }
    else if (h < 180){ g = c; b = x; } else if (h < 240){ g = x; b = c; }
    else if (h < 300){ r = x; b = c; } else { r = c; b = x; }
    return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)];
  }
  function hexToHsl(hex){
    var m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ""));
    if (!m) return { h:0, s:0, l:0.5 };
    var n = parseInt(m[1], 16);
    var a = rgbToHsl((n >> 16) & 255, (n >> 8) & 255, n & 255);
    return { h:a[0], s:a[1], l:a[2] };
  }
  /* ek pixel ko original colour (o) se target colour (t) ki taraf le jao.
     p5/p95 = is photo ke kapde ki lightness range (shading bachane ke liye) */
  function shiftPixel(r, g, b, o, t, p5, p95){
    var a = rgbToHsl(r, g, b), h = a[0], s = a[1], L = a[2];
    var lo = Math.max(0.015, t.l - 0.30), hi = Math.min(0.985, t.l + 0.32), rng = p95 - p5;
    var l2 = rng > 0.05 ? lo + clamp01((L - p5) / rng) * (hi - lo)
                        : clamp01(t.l + (L - o.l) * 0.92);
    var h2, s2;
    if (s > 0.10){ h2 = h + (t.h - o.h); s2 = clamp01(s * (t.s / Math.max(o.s, 0.30))); }
    else { h2 = t.h; s2 = clamp01(t.s * (1 - Math.abs(l2 - 0.5) * 0.85)); }
    return hslToRgb(h2, s2, l2);
  }
  var cache = {};
  /* recolorSrc(src, origHex, targetHex, keyPrefix, done) — done(dataURL|null) */
  function recolorSrc(src, origHex, targetHex, keyPrefix, done){
    var key = (keyPrefix || "") + "|" + targetHex + "|" + src;
    if (cache[key]){ done(cache[key]); return; }
    var im = new Image();
    im.onload = function(){
      try {
        var w = im.naturalWidth || im.width, hh = im.naturalHeight || im.height;
        if (!w || !hh){ done(null); return; }
        var cv = document.createElement("canvas"); cv.width = w; cv.height = hh;
        var cx = cv.getContext("2d"); cx.drawImage(im, 0, 0);
        var id = cx.getImageData(0, 0, w, hh), d = id.data;
        var o = hexToHsl(origHex), tc = hexToHsl(targetHex), samples = [], i, j;
        for (i = 0; i < d.length; i += 16) if (d[i + 3] > 10) samples.push(rgbToHsl(d[i], d[i + 1], d[i + 2])[2]);
        samples.sort(function(x, y){ return x - y; });
        var p5 = samples.length ? samples[Math.floor(samples.length * 0.05)] : 0;
        var p95 = samples.length ? samples[Math.min(samples.length - 1, Math.floor(samples.length * 0.95))] : 1;
        for (j = 0; j < d.length; j += 4){
          if (d[j + 3] === 0) continue;
          var px = shiftPixel(d[j], d[j + 1], d[j + 2], o, tc, p5, p95);
          d[j] = px[0]; d[j + 1] = px[1]; d[j + 2] = px[2];
        }
        cx.putImageData(id, 0, 0);
        var url = cv.toDataURL("image/png");
        cache[key] = url; done(url);
      } catch (err){ done(null); }
    };
    im.onerror = function(){ done(null); };
    im.src = src;
  }
  /* canvas na chale (jaise file:// par taint) to CSS filter fallback.
     Bahut halke/gehre kapde par hue-rotate kaam nahi karta — unke liye colorize chain. */
  function colourFilter(origHex, targetHex){
    var o = hexToHsl(origHex), t = hexToHsl(targetHex);
    if (o.s > 0.12 && o.l >= 0.12 && o.l <= 0.80){
      var dh = Math.round(t.h - o.h);
      var ss = Math.max(0.25, Math.min(2.2, t.s / Math.max(o.s, 0.30))).toFixed(2);
      var bb = Math.max(0.55, Math.min(1.5, t.l / Math.max(o.l, 0.18))).toFixed(2);
      return "hue-rotate(" + dh + "deg) saturate(" + ss + ") brightness(" + bb + ")";
    }
    var hr = Math.round(t.h - 38);
    var sat = (1 + t.s * 3.2).toFixed(2);
    var br = Math.max(0.5, Math.min(1.35, 0.35 + t.l * 1.45)).toFixed(2);
    return "grayscale(1) sepia(0.9) saturate(" + sat + ") hue-rotate(" + hr + "deg) brightness(" + br + ") contrast(1.05)";
  }

  window.Recolor = {
    clamp01: clamp01, rgbToHsl: rgbToHsl, hslToRgb: hslToRgb, hexToHsl: hexToHsl,
    shiftPixel: shiftPixel, recolorSrc: recolorSrc, colourFilter: colourFilter
  };
})();
