/* ============================================================
   ADMIN LOCK — saare admin pages ke liye ek hi password
   admin.html · label.html · tools/product-manager.html

   PASSWORD BADALNA HO TO: niche "NIHAL123" ki jagah likh dein.
   Ye file <head> me load karni hai (flash na ho isliye).
   ============================================================ */
(function () {
  var PASS  = "NIHAL123";          // <-- yahan apna password
  var KEY   = "pm_ok";             // localStorage key
  var HOURS = 8;                   // itne ghante baad khud lock ho jayega

  window.ADMIN_PASS = PASS;

  /* password check — trim + caps ignore (lockout se bachav) */
  window.adminCheck = function (v) {
    return !!v && String(v).trim().toUpperCase() === PASS.toUpperCase();
  };

  /* unlocked hai ya nahi — localStorage (naye tab me bhi kaam kare) */
  window.adminIsUnlocked = function () {
    try {
      var ts = parseInt(localStorage.getItem(KEY) || "0", 10);
      if (!ts) return false;
      if (Date.now() - ts > HOURS * 3600 * 1000) { localStorage.removeItem(KEY); return false; }
      return true;
    } catch (e) { return false; }
  };

  window.adminSetUnlocked = function () {
    try { localStorage.setItem(KEY, String(Date.now())); } catch (e) {}
  };

  window.adminLockNow = function () {
    try { localStorage.removeItem(KEY); sessionStorage.removeItem("pm_ok"); } catch (e) {}
    document.documentElement.classList.remove("unlocked");
    location.reload();
  };

  /* page ko dikhao (gate hatao) */
  window.adminMarkUnlocked = function () {
    document.documentElement.classList.add("unlocked");
    var g = document.getElementById("gate");
    if (g) g.style.display = "none";
  };

  /* page load par: gate dikhayein ya seedha andar */
  window.adminLockBoot = function () {
    if (window.adminIsUnlocked()) { window.adminMarkUnlocked(); return true; }
    var g = document.getElementById("gate");
    if (g) g.style.display = "flex";
    var p = document.getElementById("pw");
    if (p) setTimeout(function () { try { p.focus(); } catch (e) {} }, 60);
    document.documentElement.classList.remove("unlocked");
    return false;
  };

  /* Unlock button / Enter key */
  window.adminTryUnlock = function (after) {
    var p = document.getElementById("pw");
    var v = p ? p.value : "";
    if (window.adminCheck(v)) {
      window.adminSetUnlocked();
      window.adminMarkUnlocked();
      if (typeof after === "function") after();
      return true;
    }
    var h = document.getElementById("gatehint");
    if (h) h.textContent = "Galat password — dobara koshish karein";
    if (p) { p.value = ""; setTimeout(function () { try { p.focus(); } catch (e) {} }, 40); }
    return false;
  };

  /* ---------- gate ka CSS (head me inject, isliye koi flash nahi) ----------
     NOTE: ye sirf unhi pages par lagega jinke <body> me class="lockable"
     aur gate me class="adminlock" ho — isse Product Manager ka apna gate
     (jo alag design ka hai) kharaab nahi hoga.                          */
  var css = [
    "#gate.adminlock{position:fixed;inset:0;z-index:99999;background:#0F1419;display:none;",
    "  align-items:center;justify-content:center;padding:20px;",
    "  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif}",
    "html.unlocked #gate.adminlock{display:none !important}",
    "html:not(.unlocked) body.lockable > *:not(#gate):not(script):not(link):not(style){display:none !important}",
    "html:not(.unlocked) body.lockable{background:#0F1419}",
    ".gatebox{background:#fff;border-radius:14px;padding:26px 24px;width:100%;max-width:360px;",
    "  text-align:center;box-shadow:0 10px 40px rgba(0,0,0,.45)}",
    ".gatebox .ico{font-size:40px;line-height:1}",
    ".gatebox h2{margin:8px 0 6px;font-size:19px;color:#111827}",
    ".gatebox p{margin:0 0 16px;color:#6B7280;font-size:13px;line-height:1.5}",
    ".gatebox input{width:100%;border:1px solid #C9CED6;border-radius:9px;padding:12px;font-size:15px;",
    "  margin-bottom:10px;box-sizing:border-box;letter-spacing:.06em}",
    ".gatebox input:focus{outline:2px solid #7A1F2B;outline-offset:1px;border-color:#7A1F2B}",
    ".gatebox button{width:100%;background:#7A1F2B;color:#fff;border:0;border-radius:9px;padding:12px;",
    "  font-size:15px;font-weight:700;cursor:pointer}",
    ".gatebox button:hover{background:#631822}",
    ".gatebox .hint2{margin-top:10px;font-size:12px;color:#B3261E;min-height:16px}",
    "@media print{html:not(.unlocked) body.lockable > *{display:none !important}}"
  ].join("\n");

  var s = document.createElement("style");
  s.setAttribute("data-admin-lock", "1");
  s.textContent = css;
  (document.head || document.documentElement).appendChild(s);

  /* head me hi check — content flash hone se bachao */
  if (window.adminIsUnlocked()) document.documentElement.classList.add("unlocked");
})();
