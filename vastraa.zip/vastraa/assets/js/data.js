/* ============================================================
   STORE CONFIG — client ke hisaab se sirf yahan badlo
   ============================================================ */
var CONFIG = {
  name: "VastraWave",
  tagline: "MEN · WOMEN · CORSETS · TEES · BOTTOMS",
  phone: "919876543210",
  email: "orders@vastrawave.store",
  address: "Bardoli, Surat, Gujarat 394601",
  pickupAddress: "VastraWave (Warehouse), Ground Floor, Near Station Road, Bardoli, Surat, Gujarat - 394601",
  pickupPhone: "+91 98765 43210",
  gstin: "GSTIN — client ka number yahan aayega",

  freeShippingAbove: 999,
  shippingCharge: 60,
  codAvailable: true,
  packagingWeight: 50,

  coupon: { code: "VASTRAA10", percent: 10, minCart: 999 },
  prepaidPercent: 5,              // prepaid (UPI/card) par extra 5% off — COD kam karne ke liye

  dispatchBeforeHour: 15,         // 3 pm se pehle ke orders aaj dispatch
  deliveryMinDays: 3,
  deliveryMaxDays: 6,

  couriers: ["Delhivery", "DTDC", "Xpressbees", "Ecom Express", "India Post", "Shiprocket", "Blue Dart", "Other / Local"],

  // Header ke upar ghoomne wali offers
  announces: [
    "FREE shipping above ₹999 · <b>VASTRAA10</b> — 10% off",
    "Extra <b>5% OFF</b> on prepaid orders (UPI / Card)",
    "COD available · 7-day easy exchange"
  ]
};

/* ============================================================
   PRODUCTS — Women (Corsets, Ladies Wear, Bottoms)
              Men (T-Shirts, Shirts, Bottoms)
              Unisex (Tees)
   Naya product = ek object copy-paste kar ke badlo.
   wt = grams (shipping label me use hota hai)
   ============================================================ */
var PRODUCTS = [
  /* ---------------- WOMEN : CORSETS ---------------- */
  {
    id: "CR101", name: "Satin Bustier Corset — Black", gender: "Women", category: "Corsets",
    price: 1299, mrp: 2199, rating: 4.6, reviews: 184, badge: "Bestseller", wt: 250,
    img: "assets/img/c1-corset-black.jpg",
    gallery: ["assets/img/c1-corset-black.jpg", "assets/img/views/CR101-side.jpg", "assets/img/views/CR101-back.jpg", "assets/img/a2-corset-back.jpg"],
    views: {front:"assets/img/cutouts/front/CR101.webp", side:"assets/img/cutouts/side/CR101.webp", back:"assets/img/cutouts/back/CR101.webp"},
    colours: [{n:"Black",h:"#1A1A1A"},{n:"Maroon",h:"#6E1B26"},{n:"Ivory",h:"#F0E7D6"}],
    sizes: ["S","M","L","XL","XXL"], stock: {S:6,M:9,L:7,XL:0,XXL:3},
    fabric: "Satin with 10 spiral steel bones, front hook closure",
    care: "Dry clean only. Do not machine wash.",
    extra: "Adjustable back lacing — waist cinch up to 3 inch",
    model: "Model is 5'6\" wearing size M",
    desc: "Structured satin bustier corset with spiral steel boning — waist define karta hai bina discomfort ke. Front hooks se pehnna aasan hai aur back lacing se fit adjust hota hai.",
    highlights: ["10 spiral steel bones", "Front hook closure", "Adjustable back lacing", "Waist cinch up to 3 inch"]
  },
  {
    id: "CR102", name: "Lace Overbust Corset — Maroon", gender: "Women", category: "Corsets",
    price: 1799, mrp: 2999, rating: 4.5, reviews: 112, badge: "", wt: 300,
    img: "assets/img/views/CR102-front.jpg",
    gallery: ["assets/img/views/CR102-front.jpg", "assets/img/views/CR102-side.jpg", "assets/img/c2-corset-lace.jpg"],
    views: {front:"assets/img/cutouts/front/CR102.webp", side:"assets/img/cutouts/side/CR102.webp", back:"assets/img/cutouts/back/CR102.webp"},
    colours: [{n:"Maroon",h:"#6E1B26"},{n:"Black",h:"#1A1A1A"},{n:"Wine",h:"#5B2333"}],
    sizes: ["S","M","L","XL","XXL"], stock: {S:4,M:6,L:5,XL:4,XXL:2},
    fabric: "Floral lace over satin base, 12 bones",
    care: "Dry clean only. Store flat.",
    extra: "Matching thong included",
    model: "Model is 5'5\" wearing size S",
    desc: "Premium lace overbust corset — party, shoot ya bridal styling ke liye. Satin base hai to chipakta nahi, comfort rahta hai.",
    highlights: ["Floral lace over satin", "12 bone construction", "Overbust coverage", "Matching thong included"]
  },

  /* ---------------- WOMEN : LADIES WEAR ---------------- */
  {
    id: "LW201", name: "Floral Printed Midi Dress", gender: "Women", category: "Ladies Wear",
    price: 1499, mrp: 2499, rating: 4.4, reviews: 268, badge: "New", wt: 320,
    img: "assets/img/d1-dress-floral.jpg",
    gallery: ["assets/img/d1-dress-floral.jpg", "assets/img/views/LW201-side.jpg", "assets/img/views/LW201-back.jpg", "assets/img/a3-dress-model.jpg"],
    views: {front:"assets/img/cutouts/front/LW201.webp", side:"assets/img/cutouts/side/LW201.webp", back:"assets/img/cutouts/back/LW201.webp"},
    colours: [{n:"Pink Floral",h:"#E8A0B4"},{n:"Blue Floral",h:"#8FA9C9"}],
    sizes: ["S","M","L","XL","XXL"], stock: {S:5,M:8,L:0,XL:6,XXL:2},
    fabric: "Rayon crepe, fully lined",
    care: "Machine wash cold, dry in shade.",
    extra: "",
    model: "Model is 5'4\" wearing size M",
    desc: "Flowy midi dress with a soft floral print — brunch ho ya office party, dono jagah chalti hai. Lining hai to transparent nahi hai.",
    highlights: ["Fully lined", "Midi length (46 inch)", "Side pockets", "Breathable rayon crepe"]
  },
  {
    id: "LW202", name: "Sequin Party Gown — Wine", gender: "Women", category: "Ladies Wear",
    price: 2999, mrp: 4999, rating: 4.7, reviews: 96, badge: "Party", wt: 650,
    img: "assets/img/d2-gown-wine.jpg",
    gallery: ["assets/img/d2-gown-wine.jpg", "assets/img/views/LW202-side.jpg", "assets/img/views/LW202-back.jpg"],
    views: {front:"assets/img/cutouts/front/LW202.webp", side:"assets/img/cutouts/side/LW202.webp", back:"assets/img/cutouts/back/LW202.webp"},
    colours: [{n:"Wine",h:"#6E1B26"},{n:"Emerald",h:"#1E5E4A"},{n:"Black",h:"#1A1A1A"}],
    sizes: ["S","M","L","XL"], stock: {S:2,M:3,L:3,XL:1},
    fabric: "Georgette with sequin embroidery, can-can layered",
    care: "Dry clean only.",
    extra: "Padded bust, side zip closure",
    model: "Model is 5'7\" wearing size M",
    desc: "Floor-length sequin gown with can-can layering — reception, sangeet ya cocktail ke liye. Padded bust hai to blouse ki tension nahi.",
    highlights: ["Sequin embroidery", "Can-can layered flare", "Padded bust", "Side zip"]
  },
  {
    id: "LW203", name: "Peplum Cotton Top — Cream", gender: "Women", category: "Ladies Wear",
    price: 899, mrp: 1499, rating: 4.3, reviews: 341, badge: "", wt: 180,
    img: "assets/img/d3-top-cream.jpg",
    gallery: ["assets/img/d3-top-cream.jpg", "assets/img/views/LW203-side.jpg", "assets/img/views/LW203-back.jpg"],
    views: {front:"assets/img/cutouts/front/LW203.webp", side:"assets/img/cutouts/side/LW203.webp", back:"assets/img/cutouts/back/LW203.webp"},
    colours: [{n:"Cream",h:"#F0E7D6"},{n:"Sage",h:"#A8B99A"},{n:"Black",h:"#1A1A1A"}],
    sizes: ["S","M","L","XL","XXL"], stock: {S:7,M:9,L:8,XL:5,XXL:0},
    fabric: "100% cotton poplin",
    care: "Machine wash cold. Warm iron.",
    extra: "",
    model: "Model is 5'3\" wearing size S",
    desc: "Everyday peplum top — jeans ke saath ho ya trousers ke saath, ek clean smart look. Pure cotton to poore din aaram.",
    highlights: ["100% cotton poplin", "Peplum waist", "Half sleeves", "Office & casual"]
  },

  /* ---------------- WOMEN : BOTTOMS ---------------- */
  {
    id: "WB301", name: "Flared Palazzo — Cream", gender: "Women", category: "Bottoms", chartKey: "Women Bottoms",
    price: 899, mrp: 1499, rating: 4.2, reviews: 143, badge: "", wt: 280,
    img: "assets/img/w1-palazzo-cream.jpg",
    gallery: ["assets/img/w1-palazzo-cream.jpg"],
    colours: [{n:"Cream",h:"#F0E7D6"},{n:"Black",h:"#1A1A1A"},{n:"Rust",h:"#B4551F"}],
    sizes: ["S","M","L","XL","XXL"], stock: {S:6,M:8,L:7,XL:0,XXL:3},
    fabric: "Rayon flex, elasticated waistband",
    care: "Machine wash cold.",
    extra: "Elasticated back waist + side pockets",
    model: "Model is 5'4\" wearing size M",
    desc: "Flowy flared palazzo — kurti ke saath ho ya crop top ke saath, har combination me chalti hai. Pure summer comfortable.",
    highlights: ["Wide flare", "Elasticated waistband", "Side pockets", "Full length (39 inch)"]
  },
  {
    id: "WB302", name: "Denim A-Line Skirt — Light Blue", gender: "Women", category: "Bottoms", chartKey: "Women Bottoms",
    price: 1199, mrp: 1899, rating: 4.4, reviews: 87, badge: "New", wt: 320,
    img: "assets/img/w2-skirt-denim.jpg",
    gallery: ["assets/img/w2-skirt-denim.jpg"],
    colours: [{n:"Light Blue",h:"#8FA9C9"},{n:"Black",h:"#232323"},{n:"White",h:"#F2F0EA"}],
    sizes: ["S","M","L","XL","XXL"], stock: {S:5,M:7,L:0,XL:4,XXL:2},
    fabric: "Cotton denim with 2% elastane",
    care: "Machine wash cold separately.",
    extra: "Button & zip closure, 5 pockets",
    model: "Model is 5'5\" wearing size S",
    desc: "Classic A-line denim skirt with slight stretch — tees, shirts, corsets, sabke saath jati hai.",
    highlights: ["A-line silhouette", "Slight stretch denim", "5 pockets", "Above-knee length (17 inch)"]
  },

  /* ---------------- UNISEX : T-SHIRTS ---------------- */
  {
    id: "TS301", name: "Oversized Boxy T-Shirt — White", gender: "Unisex", category: "T-Shirts",
    price: 999, mrp: 1499, rating: 4.6, reviews: 512, badge: "Bestseller", wt: 220,
    img: "assets/img/t1-tee-white.jpg",
    gallery: ["assets/img/t1-tee-white.jpg", "assets/img/a1-tee-back.jpg"],
    views: {front:"assets/img/cutouts/front/TS301.webp", back:"assets/img/cutouts/back/TS301.webp"},
    colours: [{n:"White",h:"#F5F5F5"},{n:"Beige",h:"#D8C7B0"},{n:"Black",h:"#1A1A1A"}],
    sizes: ["S","M","L","XL","XXL"], stock: {S:12,M:15,L:14,XL:10,XXL:6},
    fabric: "240 GSM 100% combed cotton (bio-washed)",
    care: "Machine wash cold, inside out. Do not iron on print.",
    extra: "",
    model: "Model is 5'11\" wearing size L (oversized fit)",
    desc: "Heavy 240 GSM oversized tee — boxy fit, drop shoulder, aur shrink nahi hota. Unisex sizing, sabke liye.",
    highlights: ["240 GSM premium cotton", "Drop shoulder boxy fit", "Bio-washed, zero shrink", "Unisex"]
  },
  {
    id: "TS302", name: "Graphic Printed T-Shirt — Black", gender: "Unisex", category: "T-Shirts",
    price: 999, mrp: 1499, rating: 4.4, reviews: 227, badge: "", wt: 210,
    img: "assets/img/t2-tee-graphic.jpg",
    gallery: ["assets/img/t2-tee-graphic.jpg"],
    colours: [{n:"Black",h:"#1A1A1A"},{n:"Olive",h:"#6B7045"},{n:"White",h:"#F5F5F5"}],
    sizes: ["S","M","L","XL","XXL"], stock: {S:8,M:10,L:0,XL:7,XXL:4},
    fabric: "180 GSM 100% cotton, DTF print",
    care: "Machine wash cold, inside out.",
    extra: "",
    model: "Model is 5'10\" wearing size M",
    desc: "Minimal abstract graphic tee — regular fit, soft hand feel. Print crack nahi hota (DTF printing).",
    highlights: ["DTF print — no cracking", "Regular unisex fit", "180 GSM cotton", "Pre-shrunk"]
  },

  /* ---------------- MEN : SHIRTS ---------------- */
  {
    id: "MS401", name: "Checkered Casual Shirt — Blue", gender: "Men", category: "Shirts",
    price: 1299, mrp: 1999, rating: 4.5, reviews: 168, badge: "New", wt: 300,
    img: "assets/img/m1-shirt-check.jpg",
    gallery: ["assets/img/m1-shirt-check.jpg"],
    colours: [{n:"Blue Check",h:"#3E5C7A"},{n:"Red Check",h:"#8A3A3A"},{n:"Green Check",h:"#5B6B4A"}],
    sizes: ["S","M","L","XL","XXL"], stock: {S:5,M:9,L:8,XL:6,XXL:0},
    fabric: "100% cotton twill, regular fit",
    care: "Machine wash cold. Warm iron.",
    extra: "Button-down collar, chest pocket",
    model: "Model is 6'0\" wearing size L",
    desc: "Everyday checkered shirt — office casual ho ya weekend, dono me chalta hai. Soft-washed cotton, heavy nahi.",
    highlights: ["100% cotton twill", "Button-down collar", "Chest pocket", "Regular fit"]
  },
  {
    id: "MS402", name: "Solid Formal Shirt — White", gender: "Men", category: "Shirts",
    price: 1299, mrp: 1999, rating: 4.3, reviews: 204, badge: "", wt: 320,
    img: "assets/img/m2-shirt-formal.jpg",
    gallery: ["assets/img/m2-shirt-formal.jpg"],
    colours: [{n:"White",h:"#F5F5F5"},{n:"Sky Blue",h:"#A9C4DC"},{n:"Grey",h:"#8E8E8E"}],
    sizes: ["S","M","L","XL","XXL"], stock: {S:6,M:10,L:9,XL:7,XXL:4},
    fabric: "Cotton-rich poplin, slim fit",
    care: "Machine wash cold. Warm iron.",
    extra: "Spread collar, curved hem",
    model: "Model is 5'11\" wearing size M",
    desc: "Crisp formal shirt — interview, meeting ya shaadi, sab jagah kaam aata hai. Wrinkle-resistant finish.",
    highlights: ["Cotton-rich poplin", "Slim fit", "Spread collar", "Wrinkle resistant"]
  },

  /* ---------------- MEN : BOTTOMS ---------------- */
  {
    id: "MB501", name: "Slim Fit Jeans — Dark Blue", gender: "Men", category: "Bottoms",
    price: 1899, mrp: 2999, rating: 4.5, reviews: 231, badge: "Bestseller", wt: 600,
    img: "assets/img/mb1-jeans-men.jpg",
    gallery: ["assets/img/mb1-jeans-men.jpg"],
    colours: [{n:"Dark Blue",h:"#2C3E5C"},{n:"Black",h:"#232323"},{n:"Light Blue",h:"#7C9AB8"}],
    sizes: ["28","30","32","34","36"], stock: {"28":4,"30":10,"32":12,"34":8,"36":3},
    fabric: "98% cotton 2% elastane stretch denim",
    care: "Machine wash cold separately. Do not bleach.",
    extra: "Mid-rise, 5 pockets, zip fly",
    model: "Model is 6'0\" wearing waist 32",
    desc: "Slim fit stretch denim — shape bhi rakhta hai aur aaram bhi. Office ke liye ho ya weekend ke liye, ek hi jeans kaafi.",
    highlights: ["Slim fit, tapered leg", "2% stretch comfort", "5 pockets, zip fly", "Fade-resistant wash"]
  },
  {
    id: "MB502", name: "Cargo Joggers — Olive", gender: "Men", category: "Bottoms",
    price: 1399, mrp: 2199, rating: 4.4, reviews: 129, badge: "", wt: 450,
    img: "assets/img/mb2-jogger-olive.jpg",
    gallery: ["assets/img/mb2-jogger-olive.jpg"],
    colours: [{n:"Olive",h:"#6B7045"},{n:"Black",h:"#232323"},{n:"Beige",h:"#C4B49A"}],
    sizes: ["28","30","32","34","36"], stock: {"28":5,"30":8,"32":9,"34":6,"36":0},
    fabric: "Cotton twill with 2% elastane",
    care: "Machine wash cold.",
    extra: "Elasticated cuffs, 6 pockets, drawstring waist",
    model: "Model is 5'10\" wearing waist 32",
    desc: "Utility cargo joggers — travel, gym ya daily wear ke liye. Elasticated cuff aur 6 pockets to sab samaan aa jata hai.",
    highlights: ["6 utility pockets", "Elasticated cuffs", "Drawstring + elastic waist", "Stretch twill"]
  }
];

/* Demo reviews */
var REVIEWS = {
  CR101: [
    {who:"Sneha R.", city:"Surat", stars:5, txt:"Quality bahut achhi hai, boning strong hai. Size chart perfect match hua."},
    {who:"Ayesha K.", city:"Mumbai", stars:4, txt:"Fit lovely hai, delivery 4 din me mil gayi."}
  ],
  TS301: [
    {who:"Rahul D.", city:"Bardoli", stars:5, txt:"240 GSM fabric genuinely heavy hai. Oversized fit bilkul photo jaisa."},
    {who:"Nisha P.", city:"Navsari", stars:5, txt:"Wash ke baad shrink bilkul nahi hua."}
  ],
  MB501: [
    {who:"Karan M.", city:"Surat", stars:5, txt:"Waist 32 liya, exact fit. Stretch hai to baithne me aaram."},
    {who:"Imran S.", city:"Ankleshwar", stars:4, txt:"Colour fade nahi hua 3 wash ke baad."}
  ],
  MS401: [
    {who:"Vikas T.", city:"Vadodara", stars:4, txt:"Office casual ke liye perfect. Cotton soft hai."}
  ],
  LW202: [
    {who:"Falguni S.", city:"Vadodara", stars:5, txt:"Reception ke liye liya — sabne poocha kahan se liya."}
  ]
};

/* Size chart — category ke hisaab se (inches) */
var SIZE_CHART = {
  "Corsets": {
    S:"Bust 32–33, Waist 25–26, Length 13",
    M:"Bust 34–35, Waist 27–28, Length 13.5",
    L:"Bust 36–37, Waist 29–30, Length 14",
    XL:"Bust 38–40, Waist 31–33, Length 14.5",
    XXL:"Bust 41–43, Waist 34–36, Length 15"
  },
  "Ladies Wear": {
    S:"Bust 34, Waist 28, Hip 36, Length 44",
    M:"Bust 36, Waist 30, Hip 38, Length 45",
    L:"Bust 38, Waist 32, Hip 40, Length 46",
    XL:"Bust 40, Waist 34, Hip 42, Length 47",
    XXL:"Bust 42, Waist 36, Hip 44, Length 48"
  },
  "Women Bottoms": {
    S:"Waist 28, Hip 36, Length 38",
    M:"Waist 30, Hip 38, Length 38.5",
    L:"Waist 32, Hip 40, Length 39",
    XL:"Waist 34, Hip 42, Length 39.5",
    XXL:"Waist 36, Hip 44, Length 40"
  },
  "T-Shirts": {
    S:"Chest 38, Length 26, Shoulder 16.5",
    M:"Chest 40, Length 27, Shoulder 17.5",
    L:"Chest 42, Length 28, Shoulder 18.5",
    XL:"Chest 44, Length 29, Shoulder 19.5",
    XXL:"Chest 46, Length 30, Shoulder 20.5"
  },
  "Shirts": {
    S:"Chest 38, Length 28, Sleeve 24.5",
    M:"Chest 40, Length 29, Sleeve 25",
    L:"Chest 42, Length 30, Sleeve 25.5",
    XL:"Chest 44, Length 31, Sleeve 26",
    XXL:"Chest 46, Length 31.5, Sleeve 26.5"
  },
  "Bottoms": {
    "28":"Waist 28, Hip 36, Length 40, Rise 10.5",
    "30":"Waist 30, Hip 38, Length 40.5, Rise 11",
    "32":"Waist 32, Hip 40, Length 41, Rise 11",
    "34":"Waist 34, Hip 42, Length 41.5, Rise 11.5",
    "36":"Waist 36, Hip 44, Length 42, Rise 12"
  }
};

/* Navigation */
var GENDERS   = ["Women", "Men", "Unisex"];
var CATEGORIES = ["Corsets", "Ladies Wear", "Shirts", "T-Shirts", "Bottoms"];
