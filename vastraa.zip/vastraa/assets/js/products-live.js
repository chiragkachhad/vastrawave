/* ============================================================
   LIVE PRODUCTS SHIM — data.js ke baad load hota hai.
   Priority:  1) products-live-data.js (publish kiya hua data)
              2) localStorage "vs_published" (publish snapshot)
              3) data.js ka base PRODUCTS
   ============================================================ */
(function () {
  try {
    if (Array.isArray(window.__LIVE_PRODUCTS) && window.__LIVE_PRODUCTS.length) {
      window.PRODUCTS = window.__LIVE_PRODUCTS;
      window.__PRODUCTS_SOURCE = "published-file";
      return;
    }
    var snap = localStorage.getItem("vs_published");
    if (snap) {
      var arr = JSON.parse(snap);
      if (Array.isArray(arr) && arr.length) {
        window.PRODUCTS = arr;
        window.__PRODUCTS_SOURCE = "local-published";
      }
    }
  } catch (e) { console.warn("products-live:", e); }
})();
