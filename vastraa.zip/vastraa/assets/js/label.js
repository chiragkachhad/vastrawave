/* ============================================================
   Shipping label generator
   label.html?order=VS123  -> ek label
   label.html              -> saare orders ke labels
   ============================================================ */

function piecesOf(o){
  if(o.pieces) return o.pieces;
  return (o.items || []).reduce((s, it) => {
    const m = /×(\d+)/.exec(it);
    return s + (m ? +m[1] : 1);
  }, 0);
}
function weightOf(o){
  if(o.weight) return o.weight;
  // fallback: products ka weight jodo + packaging
  let g = CONFIG.packagingWeight || 50;
  (o.items || []).forEach(it => {
    const m = /^(\w+)/.exec(it);
    const p = m && PRODUCTS.find(x => x.id === m[1]);
    if(p) g += (p.wt || 250);
  });
  return g;
}

function labelHTML(o, i){
  const pcs = piecesOf(o), wt = weightOf(o);
  const isCOD = (o.pay || "").toUpperCase() === "COD";
  return `
  <div class="label" data-id="${o.id}">
    <div class="lb-head">
      <div class="lb-brand">${CONFIG.name}<small>${CONFIG.tagline}</small></div>
      <div class="lb-oid"><b>${o.id}</b><span>${esc(o.date)}</span></div>
    </div>

    <div class="lb-sec lb-to">
      <div class="lb-cap">SHIP TO</div>
      <div class="nm">${esc(o.name)}</div>
      <div class="ad">${esc(o.address)}</div>
      <div class="ph">📞 ${esc(o.phone)}</div>
    </div>

    <div class="lb-sec">
      <div class="lb-grid">
        <div class="${isCOD ? "codbox" : ""}">
          <div class="k">${isCOD ? "COD — COLLECT" : "PAYMENT"}</div>
          <div class="v">${isCOD ? money(o.total) : "PREPAID"}</div>
        </div>
        <div>
          <div class="k">WEIGHT</div>
          <div class="v"><input class="lb-edit w" style="display:inline;width:42px;text-align:right" value="${wt}" inputmode="numeric"> g</div>
        </div>
        <div>
          <div class="k">PIECES</div>
          <div class="v">${pcs}</div>
        </div>
      </div>
    </div>

    <div class="lb-sec">
      <div class="lb-cap">CONTENTS</div>
      <div class="lb-items">${(o.items || []).map(it => `<div>• ${esc(it)}</div>`).join("")}</div>
    </div>

    <div class="lb-sec">
      <div class="lb-cap">COURIER PARTNER / AWB</div>
      <div style="display:flex;gap:3mm">
        <select class="lb-edit c" style="flex:1.1">
          ${CONFIG.couriers.map(c => `<option ${c === (o.courier || CONFIG.couriers[0]) ? "selected" : ""}>${c}</option>`).join("")}
        </select>
        <input class="lb-edit a" style="flex:1" placeholder="AWB / docket no." value="${esc(o.awb || "")}">
      </div>
    </div>

    <div class="lb-bc">
      <canvas class="bc" data-code="${esc(o.awb || o.id)}" data-h="52"></canvas>
      <div class="awb">${esc(o.awb || o.id)}</div>
    </div>

    <div class="lb-from">
      <b>SHIP FROM / IF UNDELIVERED RETURN TO</b><br>
      ${esc(CONFIG.pickupAddress)} · ${esc(CONFIG.pickupPhone)}<br>
      ${esc(CONFIG.gstin)} · Order ${o.id} · Prepaid/COD as per payment mode
    </div>
    <div class="lb-care">HANDLE WITH CARE</div>
  </div>`;
}

function renderLabels(){
  const id = qs.get("order");
  const list = id ? getOrders().filter(o => o.id === id) : getOrders();

  if(!list.length){
    document.getElementById("sheet").innerHTML =
      `<div class="empty"><div class="e-ico">🏷️</div><h2>Koi order nahi mila</h2>
       <p class="muted">Pehle ek order place karein — phir uska label print ho jayega.</p>
       <a href="shop.html" class="btn" style="width:auto;display:inline-flex;margin-top:12px">Demo order banayein</a></div>`;
    document.getElementById("howmany").textContent = "";
    return;
  }

  document.getElementById("howmany").textContent =
    list.length + (list.length === 1 ? " label ready" : " labels ready") + " · AWB aur courier yahin fill karein";

  const html = list.map((o, i) => labelHTML(o, i)).join("");
  // A4 mode me har 2 label ke baad page break
  document.getElementById("sheet").innerHTML = html;
  wire();                 // pehle fields wire karo, phir barcode banao
  try { Barcode.paintAll(); } catch(e){}
}

/* Editable fields -> order object me save */
function wire(){
  document.querySelectorAll(".label").forEach(lab => {
    const id = lab.dataset.id;
    const sel = lab.querySelector("select.c");
    const awb = lab.querySelector("input.a");
    const wt  = lab.querySelector("input.w");

    const commit = () => {
      const l = getOrders(); const o = l.find(x => x.id === id); if(!o) return;
      o.courier = sel.value;
      o.awb = (awb.value || "").trim();
      o.weight = parseInt(wt.value, 10) || weightOf(o);
      store.set("vs_orders", l);
      const code = o.awb || o.id;
      lab.querySelector(".awb").textContent = code;
      try { Barcode.draw(lab.querySelector("canvas.bc"), code, 52); } catch(e){}
    };
    sel.addEventListener("change", commit);
    awb.addEventListener("input", commit);
    wt.addEventListener("change", commit);
  });
}

function saveAll(){
  let n = 0;
  document.querySelectorAll(".label").forEach(lab => {
    const l = getOrders(); const o = l.find(x => x.id === lab.dataset.id); if(!o) return;
    o.courier = lab.querySelector("select.c").value;
    o.awb = (lab.querySelector("input.a").value || "").trim();
    o.weight = parseInt(lab.querySelector("input.w").value, 10) || weightOf(o);
    store.set("vs_orders", l); n++;
  });
  toast(n + " label" + (n > 1 ? "s" : "") + " save ho gaye 💾");
}

function setSize(v){
  document.body.className = v === "a4" ? "size-a4" : "size-46";
  try { Barcode.paintAll(); } catch(e){}
}

document.addEventListener("DOMContentLoaded", function(){
  renderLabels();
  window.addEventListener("beforeprint", () => saveAll());
});
