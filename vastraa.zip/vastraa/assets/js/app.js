/* ============================================================
   VastraWave — shared app logic
   Cart, wishlist, header/footer, toast, WhatsApp ordering
   ============================================================ */

/* ---------- Safe storage (kuch preview iframe me localStorage block hota hai) ---------- */
const mem = {};
const store = {
  get(k, d){ try{ const v = localStorage.getItem(k); return v===null?d:JSON.parse(v); }catch(e){ return mem[k]!==undefined?mem[k]:d; } },
  set(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){ mem[k]=v; } },
  del(k){ try{ localStorage.removeItem(k); }catch(e){ delete mem[k]; } }
};

/* ---------- Helpers ---------- */
const money = n => "₹" + Number(n).toLocaleString("en-IN");
const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const productById = id => PRODUCTS.find(p => p.id === id);
const offPct = p => Math.round((1 - p.price / p.mrp) * 100);
const qs = new URLSearchParams(location.search);
const waUrl = text => "https://wa.me/" + CONFIG.phone + "?text=" + encodeURIComponent(text);

/* ---------- Toast ---------- */
function toast(msg){
  let t = document.getElementById("toast");
  if(!t){ t = document.createElement("div"); t.id = "toast"; document.body.appendChild(t); }
  t.textContent = msg; t.classList.add("show");
  clearTimeout(t._tm); t._tm = setTimeout(()=>t.classList.remove("show"), 2200);
}

/* ---------- Cart ---------- */
function getCart(){ return store.get("vs_cart", []); }
function saveCart(c){ store.set("vs_cart", c); paintCount(); }
function cartCount(){ return getCart().reduce((s,i)=>s+i.qty, 0); }
function keyOf(id, size, colour){ return id + "|" + size + "|" + colour; }

function addToCart(id, size, colour, qty){
  const p = productById(id); if(!p) return;
  size = size || p.sizes[0]; colour = colour || p.colours[0].n; qty = qty || 1;
  const c = getCart(); const k = keyOf(id, size, colour);
  const found = c.find(i => i.key === k);
  if(found) found.qty = Math.min(9, found.qty + qty);
  else c.push({ key:k, id, size, colour, qty, price:p.price, name:p.name, img:p.img });
  saveCart(c);
  toast("Cart me add ho gaya — " + p.name);
}
function setQty(k, q){
  const c = getCart(); const i = c.find(x=>x.key===k); if(!i) return;
  i.qty = Math.max(1, Math.min(9, q));
  saveCart(c); if(typeof renderCart === "function") renderCart();
}
function removeItem(k){
  store.set("vs_cart", getCart().filter(x=>x.key!==k));
  if(typeof renderCart === "function") renderCart();
  toast("Item remove ho gaya"); paintCount();
}
function clearCart(){ store.del("vs_cart"); store.del("vs_coupon"); paintCount(); }

function getCoupon(){ return store.get("vs_coupon", ""); }
function setCoupon(code){ store.set("vs_coupon", code); }

function totals(){
  const items = getCart();
  const subtotal = items.reduce((s,i)=>s + i.price*i.qty, 0);
  let discount = 0;
  if(getCoupon() === CONFIG.coupon.code && subtotal >= CONFIG.coupon.minCart)
    discount = Math.round(subtotal * CONFIG.coupon.percent / 100);
  const after = subtotal - discount;
  const shipping = (after > 0 && after < CONFIG.freeShippingAbove) ? CONFIG.shippingCharge : 0;
  return { items, subtotal, discount, shipping, total: after + shipping };
}

/* ---------- Wishlist ---------- */
function getWish(){ return store.get("vs_wish", []); }
function toggleWish(id){
  const w = getWish();
  const i = w.indexOf(id);
  if(i > -1){ w.splice(i,1); toast("Wishlist se hata diya"); }
  else { w.push(id); toast("Wishlist me save ho gaya ♥"); }
  store.set("vs_wish", w);
  document.querySelectorAll('.wish[data-id="'+id+'"]').forEach(b=>{
    b.classList.toggle("on", w.includes(id)); b.textContent = w.includes(id) ? "♥" : "♡";
  });
}

/* ---------- Chrome (header / nav / footer) ---------- */
const PAGES = [
  {href:"clothesline.html", ico:"🏠", label:"Home"},   /* MAIN PAGE = rail wala (clothesline) */
  {href:"shop.html",  ico:"🛍️", label:"Shop"},
  {href:"cart.html",  ico:"🛒", label:"Cart"},
  {href:"about.html", ico:"ℹ️", label:"Info"}
];

function injectChrome(active){
  const here = active || location.pathname.split("/").pop() || "index.html";
  const head = document.getElementById("site-header");
  if(head){
    head.innerHTML = `
      <div class="announce" id="announce"></div>
      <div class="wrap">
        <div class="top-inner">
          <a href="clothesline.html" class="logo"><img src="assets/img/logo-vastrawave.svg" alt="${CONFIG.name} logo" style="width:40px;height:40px;border-radius:12px;display:block;box-shadow:0 6px 16px rgba(224,36,94,.35)"><span>${CONFIG.name}<small>${CONFIG.tagline}</small></span></a>
          <form class="searchbar" id="searchform" onsubmit="return doSearch(event)">
            <span class="ico">🔍</span>
            <input id="searchinput" type="search" placeholder="Search corset, tee, jeans, shirt…" autocomplete="off" oninput="suggest(this.value)" onfocus="suggest(this.value)">
            <div class="sugg" id="sugg"></div>
          </form>
          <a href="cart.html" class="icon-btn" title="Cart" style="position:relative">
            🛒<span class="count" id="cartcount">0</span>
          </a>
        </div>
      </div>
      <nav class="genderbar">
        <div class="wrap gb-in">
          <a href="shop.html?gender=Women" class="${qs.get("gender")==="Women"?"on":""}">👗 Women</a>
          <a href="shop.html?gender=Men" class="${qs.get("gender")==="Men"?"on":""}">👔 Men</a>
          <a href="shop.html?sort=new">✨ New Arrivals</a>
          <a href="shop.html?sort=discount">🔥 Sale</a>
          <a href="shop.html">All Products</a>
        </div>
      </nav>`;
    rotateAnnounce();
  }
  const nav = document.getElementById("bottomnav");
  if(nav){
    nav.innerHTML = PAGES.map(p =>
      `<a href="${p.href}" class="${p.href===here?"active":""}"><span class="b-ico">${p.ico}</span>${p.label}</a>`
    ).join("");
  }
  const f = document.getElementById("site-footer");
  if(f){
    f.innerHTML = `
      <div class="wrap">
        <div class="fgrid">
          <div>
            <h4>${CONFIG.name}</h4>
            <p class="muted" style="max-width:280px">${CONFIG.tagline} — curated ethnic wear, dispatched from ${CONFIG.address}.</p>
            <p>📞 <a href="tel:+${CONFIG.phone}">+${CONFIG.phone}</a><br>✉️ ${CONFIG.email}</p>
          </div>
          <div>
            <h4>Shop</h4>
            ${CATEGORIES.map(c=>`<a href="shop.html?cat=${encodeURIComponent(c)}">${c}</a>`).join("")}
            <a href="shop.html">All products</a>
          </div>
          <div>
            <h4>Help</h4>
            <a href="about.html#shipping">Shipping policy</a>
            <a href="about.html#returns">7-day exchange</a>
            <a href="about.html#size">Size guide</a>
            <a href="about.html#contact">Contact us</a>
          </div>
          <div>
            <h4>About</h4>
            <a href="about.html">Our story</a>
            <a href="about.html#privacy">Privacy policy</a>
            <a href="about.html#terms">Terms &amp; conditions</a>
            <a href="admin.html">Store admin (demo)</a>
          </div>
        </div>
        <div class="fbottom">© ${new Date().getFullYear()} ${CONFIG.name}. Demo build — GSTIN &amp; company details client add karega.</div>
      </div>`;
  }
  const fab = document.getElementById("fab");
  if(fab) fab.innerHTML = `<a class="fab" href="${waUrl("Hi "+CONFIG.name+"! Mujhe order karna hai.")}" target="_blank" title="Order on WhatsApp">🅦</a>`;
  paintCount();
}

function paintCount(){
  const n = cartCount();
  document.querySelectorAll("#cartcount").forEach(e=>{ e.textContent = n; e.style.display = n ? "grid" : "none"; });
}

/* ---------- Rotating announcement bar ---------- */
function rotateAnnounce(){
  const el = document.getElementById("announce");
  if(!el || !CONFIG.announces || !CONFIG.announces.length) return;
  let i = 0;
  const show = () => { el.innerHTML = CONFIG.announces[i % CONFIG.announces.length]; i++; };
  show();
  setInterval(show, 4500);
}

/* ---------- Delivery estimate + dispatch countdown (Foomer-style urgency) ---------- */
function deliveryInfo(){
  const now = new Date();
  const cut = new Date(now); cut.setHours(CONFIG.dispatchBeforeHour, 0, 0, 0);
  const beforeCut = now < cut;
  const dispatch = new Date(now);
  if(!beforeCut) dispatch.setDate(dispatch.getDate() + 1);
  // cutoff tak kitna time bacha hai
  const nextCut = beforeCut ? cut : (() => { const d = new Date(now); d.setDate(d.getDate()+1); d.setHours(CONFIG.dispatchBeforeHour,0,0,0); return d; })();
  const from = new Date(dispatch), to = new Date(dispatch);
  from.setDate(from.getDate() + CONFIG.deliveryMinDays);
  to.setDate(to.getDate() + CONFIG.deliveryMaxDays);
  const fmt = d => d.toLocaleDateString("en-IN", { weekday:"long", day:"numeric", month:"long" });
  return { beforeCut, msLeft: Math.max(0, nextCut - now), dispatch: fmt(dispatch), from: fmt(from), to: fmt(to) };
}
function countdownText(ms){
  const s = Math.floor(ms/1000), d = Math.floor(s/86400), h = Math.floor(s%86400/3600), m = Math.floor(s%3600/60), sec = s%60;
  return (d ? d + " days " : "") + String(h).padStart(2,"0") + " hrs " + String(m).padStart(2,"0") + " min " + String(sec).padStart(2,"0") + " sec";
}

/* ---------- Recently viewed ---------- */
function addRecent(id){
  const r = store.get("vs_recent", []).filter(x => x !== id);
  r.unshift(id); store.set("vs_recent", r.slice(0, 8));
}
function getRecent(except){
  return store.get("vs_recent", []).filter(x => x !== except).map(productById).filter(Boolean).slice(0, 4);
}

/* ---------- Prepaid discount (COD kam karne ke liye) ---------- */
function prepaidOff(subtotal){ return Math.round(subtotal * (CONFIG.prepaidPercent || 0) / 100); }

/* ---------- Search ---------- */
function doSearch(e){
  e.preventDefault();
  const q = document.getElementById("searchinput").value.trim();
  location.href = "shop.html" + (q ? "?q=" + encodeURIComponent(q) : "");
  return false;
}
function suggest(v){
  const box = document.getElementById("sugg"); if(!box) return;
  v = v.trim().toLowerCase();
  if(v.length < 2){ box.style.display = "none"; return; }
  const m = PRODUCTS.filter(p => (p.name+" "+p.category+" "+p.fabric).toLowerCase().includes(v)).slice(0,5);
  if(!m.length){ box.style.display = "none"; return; }
  box.innerHTML = m.map(p => `<a href="product.html?id=${p.id}">
      <img src="${p.img}" alt=""><span><b>${esc(p.name)}</b><br><span class="muted tiny">${money(p.price)} · ${p.category}</span></span></a>`).join("");
  box.style.display = "block";
}
document.addEventListener("click", e=>{
  const s = document.getElementById("sugg");
  if(s && !e.target.closest(".searchbar")) s.style.display = "none";
});

/* ---------- Product card ---------- */
function cardHTML(p){
  const w = getWish().includes(p.id);
  const oneSize = p.sizes.length === 1;
  return `
  <div class="card">
    <a href="product.html?id=${p.id}">
      <div class="imgbox">
        <img src="${p.img}" alt="${esc(p.name)}" loading="lazy">
        ${p.badge ? `<span class="badge ${/off|sale/i.test(p.badge)?"gold":""}">${esc(p.badge)}</span>` : ""}
      </div>
    </a>
    <button class="wish ${w?"on":""}" data-id="${p.id}" onclick="toggleWish('${p.id}')">${w?"♥":"♡"}</button>
    <div class="body">
      <a href="product.html?id=${p.id}" class="name">${esc(p.name)}</a>
      <div class="meta">${p.gender} · ${p.category}</div>
      <div class="rating"><span class="stars">★</span> ${p.rating} <span>(${p.reviews})</span></div>
      <div class="price">
        <span class="now">${money(p.price)}</span>
        <span class="mrp">${money(p.mrp)}</span>
        <span class="off">${offPct(p)}% off</span>
      </div>
    </div>
    <div class="foot">
      <button class="btn ${oneSize?"":"ghost"}" onclick="${oneSize ? `addToCart('${p.id}')` : `location.href='product.html?id=${p.id}'`}">
        ${oneSize ? "Add to Cart" : "Select Size"}
      </button>
    </div>
  </div>`;
}
function paintGrid(el, list){
  if(!el) return;
  el.innerHTML = list.length ? list.map(cardHTML).join("")
    : `<div class="empty" style="grid-column:1/-1"><div class="e-ico">🔍</div><h3>Kuch nahi mila</h3><p class="muted">Filters hata ke dobara try karein.</p></div>`;
}

/* ---------- Modal ---------- */
function openModal(title, html){
  let m = document.getElementById("modal");
  if(!m){
    m = document.createElement("div"); m.className = "modal"; m.id = "modal";
    m.innerHTML = `<div class="sheet"><div class="mhead"><h3></h3><button class="x" onclick="closeModal()">×</button></div><div class="mbody"></div></div>`;
    m.addEventListener("click", e=>{ if(e.target === m) closeModal(); });
    document.body.appendChild(m);
  }
  m.querySelector("h3").textContent = title;
  m.querySelector(".mbody").innerHTML = html;
  m.classList.add("show");
}
function closeModal(){ const m = document.getElementById("modal"); if(m) m.classList.remove("show"); }
function sizeChart(cat){
  const c = SIZE_CHART[cat] || SIZE_CHART.Kurtis;
  const rows = Object.keys(c).map(s => `<tr><td><b>${s}</b></td><td>${c[s]}</td></tr>`).join("");
  openModal("Size chart — " + cat,
    `<table class="chart"><tr><th>Size</th><th>Measurements (inches)</th></tr>${rows}</table>
     <p class="muted tiny" style="margin-top:10px">Measurements are garment measurements. Agar aap do size ke beech me hain to ek size upar lein — exchange 7 din ke andar free hai.</p>`);
}

/* ---------- Orders (demo admin) ---------- */
function getOrders(){ return store.get("vs_orders", []); }
function saveOrder(o){ const l = getOrders(); l.unshift(o); store.set("vs_orders", l); }

/* ---------- Init ---------- */
document.addEventListener("DOMContentLoaded", ()=> injectChrome());
