/* ============================================================
   Code 39 barcode — bina kisi library ke (offline)
   Shipping label par AWB / order ID ke liye
   ============================================================ */
(function(){
  // 1 = narrow, 3 = wide. 9 elements per character, bar se shuru.
  var T = {
    "0":"111331311","1":"311131113","2":"113131113","3":"313131111","4":"111331113",
    "5":"311331111","6":"113331111","7":"111131311","8":"311131311","9":"113131311",
    "A":"311111313","B":"113111313","C":"313111113","D":"111131113","E":"311131111",
    "F":"113131111","G":"111113113","H":"311113111","I":"113113111","J":"111133111",
    "K":"311111133","L":"113111133","M":"313111131","N":"111131331","O":"311131131",
    "P":"113131131","Q":"111111333","R":"311111331","S":"113111331","T":"111131133",
    "U":"331111113","V":"133111113","W":"333111111","X":"131131113","Y":"331131111",
    "Z":"133131111","-":"131111313",".":"331111311"," ":"133111311",
    "$":"131313111","/":"131311131","+":"131113131","%":"111313131","*":"131131311"
  };

  function encode(str){
    str = String(str || "").toUpperCase().replace(/[^0-9A-Z\-\.\ \$\/\+%]/g, "");
    if(!str || !/^\*.*\*$/.test(str)) str = "*" + str + "*";
    var out = [];
    for(var i = 0; i < str.length; i++){
      var p = T[str[i]] || T["-"];
      for(var j = 0; j < 9; j++) out.push(+p[j]);   // 1 ya 3
      out.push(1);                                   // inter-character narrow gap
    }
    return out;
  }

  /* canvas par barcode draw karta hai */
  function draw(canvas, text, height){
    if(!canvas || !canvas.getContext) return false;
    var ctx = null;
    try { ctx = canvas.getContext("2d"); } catch(e){ ctx = null; }
    if(!ctx) return false;                       // canvas support nahi -> silently skip
    var bars = encode(text);
    var units = bars.reduce(function(a,b){ return a + b; }, 0);
    var dpr = window.devicePixelRatio || 1;
    var W = canvas.clientWidth || 340, H = height || 56;
    canvas.width = W * dpr; canvas.height = H * dpr;
    canvas.style.height = H + "px";
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(dpr, dpr);
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "#000";
    var unit = W / units, x = 0;
    for(var i = 0; i < bars.length; i++){
      if(i % 2 === 0) ctx.fillRect(x, 0, Math.max(0.6, bars[i] * unit), H);
      x += bars[i] * unit;
    }
    return true;
  }

  /* Sirf <canvas class="bc"> wale sabhi elements paint kar do
     (koi bhi canvas fail ho to baaki page kharaab na ho) */
  function paintAll(root){
    (root || document).querySelectorAll("canvas.bc").forEach(function(c){
      try { draw(c, c.dataset.code || "", +c.dataset.h || 56); } catch(e){}
    });
  }

  window.Barcode = { encode: encode, draw: draw, paintAll: paintAll };
})();
